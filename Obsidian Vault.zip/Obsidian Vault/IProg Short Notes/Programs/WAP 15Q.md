Print the following star pattern
~~~

1   #include <stdio.h>
  1 
  2 int main(){
  3 
  4         int n;
  5         printf("Enter a number : ");
  6         scanf("%d", &n);
  7 
  8         int x = n;
  9 
 10         for(int row = 0; row < n; row++){
 11 
 12 
 13                 for(int space = 0; space < row; space++){
 14 
 15 
 16                         printf(" ");
 17 
 18 
 19                 }
 20 
 21                 for(int j = 0; j < x; j++){
 22 
 23 
 24                         printf("*");
 25 
 26                 }
 27 
 28                 x--;
 29                 printf("\n");
 30 
 31         }
 32 
 33         return 0;
 34 }
 ~~~
 OUTPUT:-
 ~~~
Enter a number : 5
*****
 ****
  ***
   **
    *
~~~
