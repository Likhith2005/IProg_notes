WAP to swap two no's using the Ex-OR Operator

~~~
#include <stdio.h>

int main(){

        int a, b;
        printf("Enter two numbers : ");
        scanf("%d %d", &a, &b);
        a = a^b;
        b = b^a;
        a = a^b;
        printf("The two numbers which got swapped are %d %d", a, b);

        return 0;

}

~~~