WAP Enter a number check whether it is a palindrome or not

~~~
#include <stdio.h>

int main(){

        int a;
        printf("Enter a number : ");
        scanf("%d",&a);

        int n = a;
        int rem;
        int sum = 0;

        while(n > 0){

                rem = n%10;
                sum = (sum*10) + rem;
                n /= 10;
        }
        printf("%d", sum);


if(a == sum){

	printf("the number is a palindrome");

}
else{

	printf("The number is not a palindrome");


}

return 0;

}
~~~
