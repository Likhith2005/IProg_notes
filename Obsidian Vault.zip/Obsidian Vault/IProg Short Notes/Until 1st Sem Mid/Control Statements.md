It allows us to specify the orders in which , programme instructions are to be executed this is called FLOW CONTROL.
FLOW CONTROL defines moving control of programme from one part to another.
There are three types of control statements present in C
1) Decision Control (or) Sequence control 2) Iteration Control (or) Loop Control 3)Jump Control
Loop is defined as a block of statements , repeatedly executed for a certain number of times
there are 3 types of loops while , do-while , for

WHILE LOOP is a ENTRY CONTROL LOOP and DO WHILE LOOP is a EXIT CONTROL LOOP

Entry Control Loop is the loop whose test condition is checked first then the body of the loop is executed

Exit Control Loop is the loop whose test condition is checked after the execution of the body of the loop i.e at the end of the loop

break statement will terminate the loop once it is executed 
while continue statement ill take the control of the compiler to the increment decrement part of the loop

eg:-
~~~

for(int i = 0; i <= 5; i++){

	if(i == 3){
		
		break;
		
	}
	printf("%d ", i);

}
OUTPUT :- 0 1 2
~~~

~~~

for(int i = 0; i <= 5; i++){

	if(i == 3){
		
		continue;
		
	}
	printf("%d ", i);

}
OUTPUT :- 0 1 2 4 5

~~~