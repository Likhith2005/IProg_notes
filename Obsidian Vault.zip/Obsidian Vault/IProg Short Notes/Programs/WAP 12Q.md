Print the following star pattern
~~~

1   #include <stdio.h>
  1 
  2 int main(){
  3 
  4         int n;
  5         printf("Enter a number : ");
  6         scanf("%d", &n);
  7         for(int i = 0;i < n; i++){
  8 
  9                 for(int j = 0; j<=i; j++){
 10 
 11 
 12                         printf("*");
 13 
 14                 }
 15 
 16                 printf("\n");
 17 
 18         } 
 19 return 0; 
 20  
 21  }
~~~
OUTPUT:-
~~~
5
*
**
***
****
*****
~~~
