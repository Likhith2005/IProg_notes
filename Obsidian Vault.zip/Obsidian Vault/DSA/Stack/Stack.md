****Stack**** is a linear data structure that follows a particular order in which the operations are performed. The order may be ****LIFO(Last In First Out)**** or ****FILO(First In Last Out)****. ****LIFO**** implies that the element that is inserted last, comes out first and ****FILO**** implies that the element that is inserted first, comes out last.

![[Stack-Data-Structure.png]]
As we know in stack elements can be inserted or removed from only one end

**Basic Operations on Stack : 

In order to make manipulations in a stack, there are certain operations provided to us.

- **push()** to insert an element into the stack
- **pop()** to remove an element from the stack
- **top()** Returns the top element of the stack.
- **isEmpty()** returns true if stack is empty else false.
- **size()** returns the size of stack.