Print the following star pattern
~~~
1   #include <stdio.h>
  1 
  2 int main(){
  3 
  4         int n;
  5         printf("Enter a number : ");
  6         scanf("%d", &n);
  7         for(int row = 1; row <= n; row++){
  8 
  9                 for(int space = 0; space < n - row; space++){
 10 
 11                         printf(" ");
 12 
 13 
 14                 }
 15 
 16                 for(int j = 1; j <= row; j++){
 17 
 18                         printf("*");
 19 
 20                 }
 21 
 22                 printf("\n");
 23 
 24         }
 25 
 26         return 0;
 27 }
~~~
OUTPUT:-
~~~

Enter a number : 5
    *
   **
  ***
 ****
*****
~~~

