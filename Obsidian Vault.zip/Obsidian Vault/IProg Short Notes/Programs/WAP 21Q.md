WAP To Convert a octal number to a decimal number
~~~



~~~
