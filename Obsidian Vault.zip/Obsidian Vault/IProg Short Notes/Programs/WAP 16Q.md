Hollow Diamond
~~~
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int main(){
	
	int x = 5;
	for(int i = 1; i <= 5; i++){

		for(int j = 0; j < x; j++){

			printf("*");

		}
		
		for(int space = 1; space <= 2*i-1; space++){

			printf(" ");

		}

		for(int k = 0; k < x; k++){

			printf("*");
	
		}
		x--;
		printf("\n");
	}

	for(int i = 1; i <= 5; i++){

		for(int j = 1; j <= i; j++){

			printf("*");

		}

		for(int space = 0; space < (-2*i)+11; space++){

			printf(" ");


		}

		for(int k = 1; k <= i; k++){

			printf("*");

		}
		printf("\n");

	}

	return 0;
}
~~~

