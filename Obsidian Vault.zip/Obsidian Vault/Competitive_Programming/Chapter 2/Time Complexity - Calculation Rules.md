the time complexity of a function estimates how much time the algorithm will use for some input.The idea is to representing efficiency as the function of the size of the input parameters. Time Complexity of an algorithm is denoted by **O(...)**
where the three dots represent some function . n usually represents the size of the input if the input is an array it denotes the size of the array if the input is a string it denotes the length of the string.

Reasons why the algorithm is slow - 
the common reason why the algorithm is slow because if the algorithm contains too many loops that go through the input.
The more nested loop the algorithm contains the slower it is.
If they are k nested loops the time complexity is O(n^k)
A time complexity does not tell the exact number of times the code inside the loops is executed 
Big O Notation gives the upper bound of the complexity in the worst case scenario
Big-O only cares about what happens if the input size is arbitarily large it doesn't care about what happens if the input size is small.![[Screenshot from 2023-10-04 06-50-15.png]]
Since Big-O only cares about what happens if the input size is arbitarily large these properties came
![[Screenshot from 2023-10-04 06-53-47.png]]
In the above example O(f(n)) = O(n^3) because n^3 is the most dominant term in the above expression.
If the algorithm doesn't depend on n then it is a constant time complexity where n is the size of an input![[Screenshot from 2023-10-04 07-52-59.png]]
![[Screenshot from 2023-10-04 07-57-19.png]]
![[Screenshot from 2023-10-04 08-05-14.png]]
The time complexity can be dependent on one or more variables according to the particular algorithm we are dealing with.

![[Screenshot from 2023-10-04 08-06-02.png]]
since the no of calls for the above function each and every time except for 1 is 1 so the time complexity is 1 + 1 + 1 + .. (n-1)times
is n-1 then time complexity is O(n-1) = O(n)

![[Screenshot from 2023-10-04 08-06-32.png]]
the time complexity of the function is O(2^n -1) = O(2^n)![[Screenshot from 2023-10-04 08-13-59.png]]