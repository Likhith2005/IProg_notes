WAP enter 3 three no's and find out the biggest no using ternary operator ?
~~~
#include <stdio.h>
int main(){

        int a, b, c;
        printf("Enter three numbers : ");
        scanf("%d %d %d", &a, &b, &c);
        int big = (a>b)?a:b;
        big = (big > c)?big:c;
        printf("The biggest number out of the three numbers is %d",big);
        return 0;

}


~~~

OR

~~~
#include <stdio.h>

int main(){

        int a, b, c;
        printf("Enter three numbers : ");
        scanf("%d %d %d", &a, &b, &c);
        int large = (a>b)?((a>c)?a:c):((b>c)?b:c);
        printf("%d", large);
        return 0;
    }
~~~
