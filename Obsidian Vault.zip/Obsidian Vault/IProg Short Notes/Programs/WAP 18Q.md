write a program to convert a decimal number to a binary number
~~~

16 #include <stdio.h>
 15 
 14 int main(){
 13 
 12         int n;
 11         printf("Enter a number : ");
 10         scanf("%d", &n);
  9 
  8         int rem;
  7         int sum = 0, base = 1;
  6         while(n > 0){
  5  
  4  
  3                 rem = n%2;
  2                 n /= 2;
  1                 sum += rem*base;
17                  base *= 10;
  1         }
  2         printf("%d", sum);
  3         return 0;
  4 }

~~~
