WAP to convert the inputted total no of days to years , months , weeks , days.

~~~

#include <stdio.h>

int main(){

	int days;
	printf("Enter the number of days : ");
	scanf("%d", &days);

	int months , weeks, years , x;
	years = days/365;
	months = (days%365)/30;
	weeks = ((days%365)%30)/7;
	x = ((days%365)%30)%7;

	printf("%d years %d months %d weeks %d days", years, months, weeks, x);

	return 0;

}




~~~