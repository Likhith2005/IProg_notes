\n always works faster than endl because endl always causes flush.A flush operation in computer science refers to the process of writing buffered data to a storage device or a network. When a program writes data to a buffer, the data is temporarily stored in memory and is not immediately written to the storage device or network.Sometimes the whole sentence should be read as the input including the spaces this can be achieved with **getline(cin , s)** function. where s is a string.
Usage of files as input and output in contests ^c7e619
~~~
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
~~~
Defining a long long variable
~~~
		long long x = 123456789123456789LL;
~~~
LL as suffix indicates that its type is long long its size is 64 bits.
g++ compiler also provides a 128-bit type __int128_t.[Basically it will not go unit this in the contest]

(a + b) mod m = (a mod m + b mod m) mod m
	(a · b) mod m = (a mod m · b mod m) mod m 
they are precision errors in the case of floating point numbers.
Comparision between floating point numbers should be done like this 
~~~
	if (abs(a-b) < 1e-9) {
// a and b are equal
}
~~~
Using the command typedef it is possible to give a shorter name to a datatype.
suppose for example 
~~~
	long long a = 123214567;
	typedef long long ll;
	ll b = 230981239048;
~~~
the typedef is used for the shortage of that particular datatype name since in competitive programming speed is an essential factor.![[Screenshot from 2023-09-30 22-31-26.png]]
Data structures and Algorithms :
Data structures = Different ways of storing data on your computer.
Algorithms = Operations which are performed on Data structures and set of instructions for executing them.
An Abstract data structure is an abstraction of data structure which provides only a interface of what a data structure must adhere to.
The interface does not give any details on how something should be implemented or in what programming language.
Abstract data types only says how a data structure is made and what methods it should have.
![[Screenshot from 2023-10-04 06-43-41.png]]