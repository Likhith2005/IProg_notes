WAP Obtain fibonancci series upto 10 terms

~~~

1   #include <stdio.h>
  1 
  2 int main(){
  3 
  4         int number;
  5         printf("Enter a number : ");
  6         scanf("%d", &number);
  7 
  8         int n1 = 0, n2 = 1;
  9         int n3;
 10 
 11         printf("\n%d %d", n1, n2);
 12 
 13         for(int i = 2; i < number; i++){
 14 
 15                 n3 = n1 + n2;
 16                 printf(" %d", n3);
 17 
 18                 n1 = n2;
 19                 n2 = n3;
 20 
 21         }
 22 
 23         printf("\n");
 24 
 25         return 0;
 26 }
~~~
