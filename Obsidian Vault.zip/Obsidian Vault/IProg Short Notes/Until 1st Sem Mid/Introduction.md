An algorithm is a step by step procedure to perform a task
// single line comment and /* */ multi line comment
format specifiers :-
%d - integer , %i - integer , %f - float - %lf - double , %c - char , %x - hexadecimal no , %o - Octadecimal number, %% - % symbol , %[] Read array of characters , %s - Read a string

*Program execution starts from main function compilation is started from the first line of the program or the beginning of the program.

*In Printf() function the work is performed from right to left

~~~
int a = 10;
printf("%d",a, ++a, a)

OUTPUT :- 11
first the work is performed from right to left so it goes through a then ++a then it will come back to a
~~~

*Format Specifier assign the values from left to left

*If you store a printf statement inside an integer the printf function will return you the number of characters which the printf function is going to output

ASCII characters A-Z (65-90) and if you want small letters then add 32 to the ASCII number

Real const - 3.4, 4.7