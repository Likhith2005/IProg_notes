WAP enter 3 digit no find out the sum of the three digits using while loop

~~~
#include <stdio.h>

int main(){

        int a;
        printf("Enter a number : ");
        scanf("%d",&a);

        int n = a;
        int x = 0;
        while(n > 0){

                x += n%10;
                n = n/10;
        }
        printf("%d", x);

        return 0;

}
~~~
