WAP to swap two numbers without using third variable
~~~
#include <stdio.h>
int main(){

int x, y;
printf("Enter the values of x and y : ");
scanf("%d %d", &x, &y);
x = x+y;
y = x-y;
x = x-y;

printf("The values of x and y after swapping are : %d , %d", x, y);

return 0;
}
~~~