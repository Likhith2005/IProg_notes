Print the following star pattern
~~~

#include <stdio.h>
  1 
  2 int main(){
  3 
  4         int n;
  5         printf("Enter a number : ");
  6         scanf("%d", &n);
  7         int x = n;
  8         for(int i = 0;i < n; i++){
  9 
 10                 for(int j = 0; j < x; j++){
 11 
 12 
 13                         printf("*");
 14 
 15                 }
 16                 x--;
 17                 printf("\n");
 18 
 19         }
 20 return 0;
 21 
 22  }

~~~
OUTPUT:-
~~~
5
*****
****
***
**
*
~~~

