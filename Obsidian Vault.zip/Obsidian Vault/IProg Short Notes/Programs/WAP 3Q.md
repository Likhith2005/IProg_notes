WAP to Enter a character and convert it to the other case character 

~~~
#include <stdio.h>
int main(){

char a;
printf("Enter a character : ");
scanf("%c", &a);
if(a>=65 && a<=90){

	printf("The Lowercase of this particular character is %c",a+32);

}else if(a>=97 && a<=122){

	printf("The Uppercase of this particular character is %c",a-32);

}else{

	printf("You didn't enter a alphabet character you dip shit");

}

return 0;

}
~~~