WAP To convert a decimal number to a octal number
~~~

#include <stdio.h>
#include <math.h>
int main(){

	int n;
	printf("Enter a number : ");
	scanf("%d", &n);

	int rem, quotient, sum = 0, base = 1;
	while(quotient != 0){

		quotient = n/8;
		rem = n%8;
		sum += rem*base;
		base *= 10;
		n = quotient;

	}
	printf("%d", sum);
	
	return 0;
}


~~~
