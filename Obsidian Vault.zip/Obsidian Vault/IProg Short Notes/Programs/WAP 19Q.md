Write a program to convert a binary number to a decimal number
~~~

1   #include <stdio.h>
  1 #include <math.h>
  2 int main(){
  3 
  4         int n;
  5         printf("Enter a Binary number : ");
  6         scanf("%d", &n);
  7 
  8         int rem, sum, k = 0;
  9         while(n > 0){
 10 
 11 
 12                 rem = n%10;
 13                 sum += rem*(pow(2,k));
 14                 k++;
 15                 n /= 10;
 16  
 17         }
 18         printf("%d", sum);
 19         
 20         return 0;
 21 }

~~~