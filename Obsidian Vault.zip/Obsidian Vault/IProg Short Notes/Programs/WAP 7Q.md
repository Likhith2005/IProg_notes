WAP enter a no and reverse it

~~~
#include <stdio.h>

int main(){

        int a;
        printf("Enter a number : ");
        scanf("%d",&a);

        int n = a;
        int rem;
        int sum = 0;

        while(n > 0){

                rem = n%10;
                sum = (sum*10) + rem;
                n /= 10;
        }
        printf("%d", sum);

        return 0;

}
~~~
