There are three particular datatypes they are :-
1)PRIMITIVE :- Used to represent simple values
2)USER DEFINED :- Defined by the user
as
3)DERIVED :- These are derived from the primitive or built in

OPERATORS:-

! is a unary operator it negates the value of the operand
= is the assignment operator

In Computer language Zero(0) represents false and One(1) represents true.

Conditional Operator :- Also known as TERNARY OPERATOR. It works with three different expressions / conditions
i.e If condition 1 is true then condition 2 will be the result otherwise condition 3 will be the result
~~~
condition1 ? condition2 : condition 3;
eg :-
int a = 5, b=10;
int z = (a>b)?a:b;
printf("%d",z);
OUTPUT :- 10 
~~~

Bit Wise Operators :- These operates on the bits of the operand
The types of the Bit Wise Operators are :-
1 - Bit wise AND(&) :- Multiply the shitty values
6&10=2
(0110)^(1010) = (0010)
2 - Bit wise OR(|) :- Its like logic gate OR Gate god damn it
3 - Bit wise NOT(~) :- Bit wise NOT negates the each bits of the operand to calculate the resultant value


[ShortCut Method:- the NOT resultant of x is going to be -x-1 It is the resultant of using the Bit wise NOT Operator on the decimal x then the decimal -x-1 will come but the binary is the complete opposite like turning the opposite switches ]


4 - Bit wise Ex-OR(^) = If Both the bits are of same value then 0 if not then 1
6^10 = 12
(0110)^(1010) = (1100)
5 - Bit wise Left shift(<<) - Shifts the bits to the left

a << 2 here 2 means shifts the bits to the left by two units
0 0 1 1 0
1 1 0 0 0
The right places are then occupied by the zero's
a*(pow(2,n)) a << n

6 - Bit wise Right shift(>>) - Shifts the bits to the right

a >> 2 here 2 means shifts the bits to the right by two units
1 1 0 0 0
0 0 1 1 0
The left places are then occupied by the zero's
a/(pow(2,n)) a>>n