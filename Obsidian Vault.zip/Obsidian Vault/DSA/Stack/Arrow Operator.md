An **Arrow operator in C/C++** allows to access elements in [Structures](https://www.geeksforgeeks.org/structures-in-cpp/) and [Unions](https://www.geeksforgeeks.org/union-c/). It is used with a [pointer variable pointing to a structure or union](https://www.geeksforgeeks.org/self-referential-structures/). The arrow operator is formed by using a minus sign, followed by the greater than symbol as shown below.

~~~
(pointer_name)->(variable_name)
~~~
