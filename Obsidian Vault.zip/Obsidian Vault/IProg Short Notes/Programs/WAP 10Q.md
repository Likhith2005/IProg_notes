WAP Enter a number and find out it's factorial

~~~
#include <stdio.h>

int main(){

        int a;
        printf("Enter the number : ");
        scanf("%d", &a);

        int fact = 1;
        for(int i = 1; i <= a; i++){

                fact *= i;

        }

        printf("%d\n", fact);

        return 0;
}
~~~
