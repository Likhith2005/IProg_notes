## **Push:**

Adds an item to the stack. If the stack is full, then it is said to be an **Overflow condition.**

**Algorithm for push:**
~~~
begin
 if stack is full
    return
 endif
else  
 increment top
 stack[top] assign value
end else
end procedure
~~~
## **Pop:**

Removes an item from the stack. The items are popped in the reversed order in which they are pushed. If the stack is empty, then it is said to be an **Underflow** **condition.**

**Algorithm for pop:**
~~~
begin
 if stack is empty
    return
 endif
else
 store value of stack[top]
 decrement top
 return value
end else
end procedure
~~~
## **Top:**

Returns the top element of the stack.

**Algorithm for Top:**
~~~
begin 
  return stack[top]
end procedure
~~~
## **isEmpty:**

Returns true if the stack is empty, else false.

**Algorithm for isEmpty**:
~~~
begin
 if top < 1
    return true
 else
    return false
end procedure
~~~